/* Shared part of the JavCMS example HTML5 creatives (X53-X55).
 * The host passes a fragment: #w=300&h=250&dir=ltr|rtl[&rm=1][&u=<https click URL>] (IAB "clickTag" also accepted).
 * rm=1 (or prefers-reduced-motion) = no motion. No storage, no network, no same-origin access:
 * the host serves the files with "CSP: sandbox allow-scripts allow-popups allow-popups-to-escape-sandbox". */
var JXH = (function () {
  'use strict';
  var q = {};
  (location.hash.slice(1) + '&' + location.search.slice(1)).split('&').forEach(function (p) {
    var i = p.indexOf('=');
    if (i > 0) { try { q[decodeURIComponent(p.slice(0, i))] = decodeURIComponent(p.slice(i + 1)); } catch (e) { } }
  });
  var root = document.documentElement;
  var dir = q.dir === 'rtl' ? 'rtl' : 'ltr';
  root.setAttribute('dir', dir);
  var url = q.u || q.clickTag || q.clicktag || '';
  if (!/^https?:\/\/[^\s]+$/i.test(url) || /[\u0000-\u001f]/.test(url)) url = '';
  var w = Math.max(50, Math.min(1000, parseInt(q.w, 10) || 0)), h = Math.max(50, Math.min(1050, parseInt(q.h, 10) || 0));
  var mq = window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)') : null;
  var reduce = q.rm === '1' || !!(mq && mq.matches);
  if (reduce) root.classList.add('rm');
  // Better Ads / ADS-BRIEF 11.4: looping animation stops after 15 s (class "still" turns CSS animations off)
  setTimeout(function () { root.classList.add('still'); }, 15000);
  function open() { if (url) { try { window.open(url, '_blank', 'noopener'); } catch (e) { } } }
  function wireCta(btn) {
    if (!btn) return;
    if (!url) { btn.hidden = true; return; }
    btn.addEventListener('click', open);
  }
  function svg(markup) {
    var t = document.createElement('template');
    t.innerHTML = markup.trim();
    return t.content.firstElementChild;
  }
  return { q: q, dir: dir, rtl: dir === 'rtl', url: url, w: w, h: h, reduce: reduce, open: open, wireCta: wireCta, svg: svg };
})();

/* Vexmoor: Crown of Glass (fictional game) playable, 320 x 480. Five glowing shards drift over the moor; each tap
 * snaps one into the crown. After five taps or 10 s: the end card. No score, no coins, no rewards, no countdown, no sound. */
(function () {
  'use strict';
  var SCENE = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 720 720\" preserveAspectRatio=\"xMidYMid slice\"><defs><linearGradient id=\"mnsky\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop offset=\"0\" stop-color=\"#0a0f2a\"/><stop offset=\".45\" stop-color=\"#0c2134\"/><stop offset=\".66\" stop-color=\"#14384a\"/><stop offset=\"1\" stop-color=\"#050b14\"/></linearGradient><radialGradient id=\"mnneb\" cx=\".78\" cy=\".14\" r=\".55\"><stop offset=\"0\" stop-color=\"#5b3fbf\" stop-opacity=\".55\"/><stop offset=\"1\" stop-color=\"#5b3fbf\" stop-opacity=\"0\"/></radialGradient><radialGradient id=\"mnglow\" cx=\".5\" cy=\".5\" r=\".5\"><stop offset=\"0\" stop-color=\"#3ff0b5\" stop-opacity=\".5\"/><stop offset=\".5\" stop-color=\"#3ff0b5\" stop-opacity=\".14\"/><stop offset=\"1\" stop-color=\"#3ff0b5\" stop-opacity=\"0\"/></radialGradient><radialGradient id=\"mnmoon\" cx=\".4\" cy=\".4\" r=\".6\"><stop offset=\"0\" stop-color=\"#f4fffb\"/><stop offset=\"1\" stop-color=\"#b9e6d8\"/></radialGradient><linearGradient id=\"mnmist\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop offset=\"0\" stop-color=\"#3ff0b5\" stop-opacity=\"0\"/><stop offset=\".5\" stop-color=\"#9cc9bb\" stop-opacity=\".14\"/><stop offset=\"1\" stop-color=\"#050b14\" stop-opacity=\"0\"/></linearGradient><linearGradient id=\"mnrock\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop offset=\"0\" stop-color=\"#1d3a44\"/><stop offset=\"1\" stop-color=\"#050b14\"/></linearGradient><radialGradient id=\"mnpool\" cx=\".5\" cy=\".5\" r=\".5\"><stop offset=\"0\" stop-color=\"#7cf5cf\" stop-opacity=\".75\"/><stop offset=\"1\" stop-color=\"#3ff0b5\" stop-opacity=\"0\"/></radialGradient><filter id=\"mnb\" x=\"-50%\" y=\"-50%\" width=\"200%\" height=\"200%\"><feGaussianBlur stdDeviation=\"12\"/></filter></defs><rect width=\"720\" height=\"720\" fill=\"url(#mnsky)\"/><rect width=\"720\" height=\"720\" fill=\"url(#mnneb)\"/><circle cx=\"0.0\" cy=\"395.9\" r=\"0.65\" fill=\"#fff\" opacity=\"0.33\"/><circle cx=\"525.1\" cy=\"229.1\" r=\"0.70\" fill=\"#fff\" opacity=\"0.65\"/><circle cx=\"543.7\" cy=\"233.4\" r=\"1.12\" fill=\"#fff\" opacity=\"0.58\"/><circle cx=\"588.1\" cy=\"104.1\" r=\"0.75\" fill=\"#fff\" opacity=\"0.62\"/><circle cx=\"502.6\" cy=\"23.2\" r=\"1.12\" fill=\"#fff\" opacity=\"0.48\"/><circle cx=\"664.1\" cy=\"347.2\" r=\"0.45\" fill=\"#fff\" opacity=\"0.51\"/><circle cx=\"664.7\" cy=\"296.1\" r=\"1.07\" fill=\"#fff\" opacity=\"0.55\"/><circle cx=\"656.6\" cy=\"390.6\" r=\"0.75\" fill=\"#fff\" opacity=\"0.40\"/><circle cx=\"602.8\" cy=\"142.9\" r=\"0.48\" fill=\"#fff\" opacity=\"0.38\"/><circle cx=\"308.5\" cy=\"126.8\" r=\"1.42\" fill=\"#fff\" opacity=\"0.53\"/><circle cx=\"525.1\" cy=\"377.5\" r=\"0.37\" fill=\"#fff\" opacity=\"0.36\"/><circle cx=\"403.7\" cy=\"218.8\" r=\"0.81\" fill=\"#fff\" opacity=\"0.32\"/><circle cx=\"654.5\" cy=\"23.6\" r=\"0.74\" fill=\"#fff\" opacity=\"0.41\"/><circle cx=\"478.4\" cy=\"397.5\" r=\"0.92\" fill=\"#fff\" opacity=\"0.30\"/><circle cx=\"292.0\" cy=\"121.9\" r=\"0.74\" fill=\"#fff\" opacity=\"0.45\"/><circle cx=\"239.5\" cy=\"228.6\" r=\"1.04\" fill=\"#fff\" opacity=\"0.34\"/><circle cx=\"652.7\" cy=\"196.9\" r=\"1.34\" fill=\"#fff\" opacity=\"0.58\"/><circle cx=\"456.7\" cy=\"222.0\" r=\"0.91\" fill=\"#fff\" opacity=\"0.61\"/><circle cx=\"676.5\" cy=\"170.6\" r=\"1.15\" fill=\"#fff\" opacity=\"0.35\"/><circle cx=\"422.5\" cy=\"150.8\" r=\"0.70\" fill=\"#fff\" opacity=\"0.43\"/><circle cx=\"572.2\" cy=\"377.3\" r=\"0.43\" fill=\"#fff\" opacity=\"0.69\"/><circle cx=\"56.0\" cy=\"174.9\" r=\"0.48\" fill=\"#fff\" opacity=\"0.25\"/><circle cx=\"717.3\" cy=\"94.6\" r=\"1.06\" fill=\"#fff\" opacity=\"0.29\"/><circle cx=\"329.1\" cy=\"255.0\" r=\"0.47\" fill=\"#fff\" opacity=\"0.75\"/><circle cx=\"636.9\" cy=\"382.9\" r=\"1.36\" fill=\"#fff\" opacity=\"0.74\"/><circle cx=\"548.0\" cy=\"118.4\" r=\"0.31\" fill=\"#fff\" opacity=\"0.35\"/><circle cx=\"54.7\" cy=\"0.7\" r=\"1.04\" fill=\"#fff\" opacity=\"0.34\"/><circle cx=\"533.6\" cy=\"210.4\" r=\"1.13\" fill=\"#fff\" opacity=\"0.34\"/><circle cx=\"635.1\" cy=\"101.1\" r=\"0.75\" fill=\"#fff\" opacity=\"0.74\"/><circle cx=\"85.2\" cy=\"210.4\" r=\"0.30\" fill=\"#fff\" opacity=\"0.75\"/><circle cx=\"458.6\" cy=\"396.5\" r=\"0.33\" fill=\"#fff\" opacity=\"0.74\"/><circle cx=\"135.5\" cy=\"416.6\" r=\"0.98\" fill=\"#fff\" opacity=\"0.61\"/><circle cx=\"191.7\" cy=\"95.8\" r=\"0.55\" fill=\"#fff\" opacity=\"0.54\"/><circle cx=\"37.7\" cy=\"330.9\" r=\"1.14\" fill=\"#fff\" opacity=\"0.63\"/><circle cx=\"358.7\" cy=\"14.1\" r=\"0.43\" fill=\"#fff\" opacity=\"0.75\"/><circle cx=\"94.1\" cy=\"295.8\" r=\"1.37\" fill=\"#fff\" opacity=\"0.22\"/><circle cx=\"635.9\" cy=\"370.4\" r=\"1.49\" fill=\"#fff\" opacity=\"0.77\"/><circle cx=\"550.7\" cy=\"180.4\" r=\"0.60\" fill=\"#fff\" opacity=\"0.64\"/><circle cx=\"635.2\" cy=\"171.3\" r=\"0.58\" fill=\"#fff\" opacity=\"0.44\"/><circle cx=\"638.6\" cy=\"240.3\" r=\"0.72\" fill=\"#fff\" opacity=\"0.57\"/><circle cx=\"529.1\" cy=\"144.1\" r=\"1.17\" fill=\"#fff\" opacity=\"0.45\"/><circle cx=\"143.0\" cy=\"134.0\" r=\"1.48\" fill=\"#fff\" opacity=\"0.80\"/><circle cx=\"455.3\" cy=\"375.0\" r=\"1.40\" fill=\"#fff\" opacity=\"0.32\"/><circle cx=\"464.6\" cy=\"58.2\" r=\"0.90\" fill=\"#fff\" opacity=\"0.53\"/><circle cx=\"555.4\" cy=\"406.7\" r=\"0.88\" fill=\"#fff\" opacity=\"0.31\"/><circle cx=\"321.6\" cy=\"71.4\" r=\"1.10\" fill=\"#fff\" opacity=\"0.51\"/><circle cx=\"404.3\" cy=\"217.9\" r=\"1.21\" fill=\"#fff\" opacity=\"0.42\"/><circle cx=\"540.6\" cy=\"11.2\" r=\"0.66\" fill=\"#fff\" opacity=\"0.53\"/><circle cx=\"146.0\" cy=\"310.9\" r=\"0.65\" fill=\"#fff\" opacity=\"0.34\"/><circle cx=\"474.9\" cy=\"184.5\" r=\"0.39\" fill=\"#fff\" opacity=\"0.66\"/><circle cx=\"592.5\" cy=\"393.6\" r=\"1.39\" fill=\"#fff\" opacity=\"0.61\"/><circle cx=\"690.4\" cy=\"10.8\" r=\"1.21\" fill=\"#fff\" opacity=\"0.56\"/><circle cx=\"521.3\" cy=\"386.2\" r=\"0.34\" fill=\"#fff\" opacity=\"0.28\"/><circle cx=\"57.8\" cy=\"46.5\" r=\"0.40\" fill=\"#fff\" opacity=\"0.21\"/><circle cx=\"435.6\" cy=\"406.7\" r=\"0.53\" fill=\"#fff\" opacity=\"0.28\"/><circle cx=\"145.6\" cy=\"290.2\" r=\"0.59\" fill=\"#fff\" opacity=\"0.47\"/><circle cx=\"715.6\" cy=\"181.7\" r=\"1.11\" fill=\"#fff\" opacity=\"0.66\"/><circle cx=\"285.8\" cy=\"179.1\" r=\"0.37\" fill=\"#fff\" opacity=\"0.34\"/><circle cx=\"581.5\" cy=\"419.0\" r=\"0.48\" fill=\"#fff\" opacity=\"0.76\"/><circle cx=\"366.3\" cy=\"52.5\" r=\"0.55\" fill=\"#fff\" opacity=\"0.56\"/><circle cx=\"122.8\" cy=\"33.6\" r=\"0.63\" fill=\"#fff\" opacity=\"0.59\"/><circle cx=\"400.4\" cy=\"206.7\" r=\"1.49\" fill=\"#fff\" opacity=\"0.25\"/><circle cx=\"297.7\" cy=\"135.2\" r=\"0.30\" fill=\"#fff\" opacity=\"0.20\"/><circle cx=\"297.7\" cy=\"39.3\" r=\"0.58\" fill=\"#fff\" opacity=\"0.75\"/><circle cx=\"559.8\" cy=\"328.5\" r=\"0.82\" fill=\"#fff\" opacity=\"0.71\"/><circle cx=\"693.0\" cy=\"344.4\" r=\"1.09\" fill=\"#fff\" opacity=\"0.54\"/><circle cx=\"250.6\" cy=\"175.0\" r=\"0.90\" fill=\"#fff\" opacity=\"0.50\"/><circle cx=\"408.5\" cy=\"310.4\" r=\"1.10\" fill=\"#fff\" opacity=\"0.58\"/><circle cx=\"524.9\" cy=\"380.3\" r=\"1.31\" fill=\"#fff\" opacity=\"0.79\"/><circle cx=\"315.4\" cy=\"209.4\" r=\"1.45\" fill=\"#fff\" opacity=\"0.79\"/><circle cx=\"257.6\" cy=\"34.1\" r=\"0.71\" fill=\"#fff\" opacity=\"0.73\"/><circle cx=\"510.0\" cy=\"317.4\" r=\"1.45\" fill=\"#fff\" opacity=\"0.67\"/><circle cx=\"149.1\" cy=\"102.4\" r=\"1.26\" fill=\"#fff\" opacity=\"0.26\"/><circle cx=\"659.2\" cy=\"344.1\" r=\"1.06\" fill=\"#fff\" opacity=\"0.63\"/><circle cx=\"385.8\" cy=\"190.5\" r=\"1.35\" fill=\"#fff\" opacity=\"0.54\"/><circle cx=\"629.1\" cy=\"116.4\" r=\"1.12\" fill=\"#fff\" opacity=\"0.46\"/><circle cx=\"284.5\" cy=\"80.6\" r=\"1.01\" fill=\"#fff\" opacity=\"0.34\"/><circle cx=\"647.2\" cy=\"353.5\" r=\"0.71\" fill=\"#fff\" opacity=\"0.61\"/><circle cx=\"631.7\" cy=\"49.8\" r=\"0.67\" fill=\"#fff\" opacity=\"0.75\"/><circle cx=\"0.9\" cy=\"56.7\" r=\"0.78\" fill=\"#fff\" opacity=\"0.21\"/><circle cx=\"498.9\" cy=\"386.1\" r=\"0.51\" fill=\"#fff\" opacity=\"0.33\"/><circle cx=\"682.1\" cy=\"300.9\" r=\"0.51\" fill=\"#fff\" opacity=\"0.27\"/><circle cx=\"451.1\" cy=\"6.9\" r=\"1.27\" fill=\"#fff\" opacity=\"0.55\"/><circle cx=\"540.8\" cy=\"55.1\" r=\"0.70\" fill=\"#fff\" opacity=\"0.63\"/><circle cx=\"687.6\" cy=\"235.6\" r=\"1.01\" fill=\"#fff\" opacity=\"0.67\"/><circle cx=\"505.8\" cy=\"315.5\" r=\"1.02\" fill=\"#fff\" opacity=\"0.26\"/><circle cx=\"32.7\" cy=\"263.7\" r=\"0.57\" fill=\"#fff\" opacity=\"0.55\"/><circle cx=\"180.7\" cy=\"95.9\" r=\"1.04\" fill=\"#fff\" opacity=\"0.58\"/><circle cx=\"585.2\" cy=\"103.0\" r=\"1.39\" fill=\"#fff\" opacity=\"0.23\"/><circle cx=\"497.3\" cy=\"174.9\" r=\"1.25\" fill=\"#fff\" opacity=\"0.60\"/><circle cx=\"579.4\" cy=\"45.0\" r=\"1.40\" fill=\"#fff\" opacity=\"0.50\"/><circle cx=\"592.5\" cy=\"182.7\" r=\"1.34\" fill=\"#fff\" opacity=\"0.67\"/><circle cx=\"523.5\" cy=\"390.4\" r=\"1.33\" fill=\"#fff\" opacity=\"0.31\"/><circle cx=\"518.2\" cy=\"66.5\" r=\"0.45\" fill=\"#fff\" opacity=\"0.77\"/><circle cx=\"687.4\" cy=\"24.3\" r=\"0.39\" fill=\"#fff\" opacity=\"0.36\"/><circle cx=\"677.3\" cy=\"374.0\" r=\"1.45\" fill=\"#fff\" opacity=\"0.37\"/><circle cx=\"142.7\" cy=\"12.8\" r=\"0.86\" fill=\"#fff\" opacity=\"0.54\"/><circle cx=\"101.9\" cy=\"138.9\" r=\"0.88\" fill=\"#fff\" opacity=\"0.34\"/><circle cx=\"39.6\" cy=\"19.1\" r=\"0.41\" fill=\"#fff\" opacity=\"0.58\"/><circle cx=\"336.9\" cy=\"347.5\" r=\"1.17\" fill=\"#fff\" opacity=\"0.51\"/><circle cx=\"504.3\" cy=\"166.9\" r=\"1.04\" fill=\"#fff\" opacity=\"0.78\"/><circle cx=\"554.9\" cy=\"413.7\" r=\"1.15\" fill=\"#fff\" opacity=\"0.56\"/><circle cx=\"578.0\" cy=\"73.6\" r=\"0.38\" fill=\"#fff\" opacity=\"0.64\"/><circle cx=\"465.6\" cy=\"185.4\" r=\"0.95\" fill=\"#fff\" opacity=\"0.43\"/><circle cx=\"356.0\" cy=\"52.4\" r=\"0.38\" fill=\"#fff\" opacity=\"0.25\"/><circle cx=\"255.0\" cy=\"148.2\" r=\"0.54\" fill=\"#fff\" opacity=\"0.58\"/><circle cx=\"90.3\" cy=\"22.4\" r=\"0.30\" fill=\"#fff\" opacity=\"0.70\"/><circle cx=\"626.0\" cy=\"19.1\" r=\"1.22\" fill=\"#fff\" opacity=\"0.39\"/><circle cx=\"289.7\" cy=\"390.5\" r=\"1.26\" fill=\"#fff\" opacity=\"0.21\"/><circle cx=\"715.2\" cy=\"88.4\" r=\"1.07\" fill=\"#fff\" opacity=\"0.46\"/><circle cx=\"23.9\" cy=\"74.3\" r=\"1.21\" fill=\"#fff\" opacity=\"0.65\"/><circle cx=\"179.4\" cy=\"368.7\" r=\"1.28\" fill=\"#fff\" opacity=\"0.39\"/><circle cx=\"330.6\" cy=\"128.5\" r=\"0.60\" fill=\"#fff\" opacity=\"0.73\"/><circle cx=\"626.4\" cy=\"291.6\" r=\"0.90\" fill=\"#fff\" opacity=\"0.72\"/><circle cx=\"590.2\" cy=\"349.6\" r=\"1.21\" fill=\"#fff\" opacity=\"0.78\"/><circle cx=\"497.8\" cy=\"122.7\" r=\"1.15\" fill=\"#fff\" opacity=\"0.39\"/><circle cx=\"622.1\" cy=\"70.1\" r=\"1.31\" fill=\"#fff\" opacity=\"0.60\"/><circle cx=\"587.5\" cy=\"200.8\" r=\"1.25\" fill=\"#fff\" opacity=\"0.70\"/><circle cx=\"30.6\" cy=\"99.7\" r=\"0.53\" fill=\"#fff\" opacity=\"0.21\"/><circle cx=\"415.8\" cy=\"349.1\" r=\"1.05\" fill=\"#fff\" opacity=\"0.71\"/><circle cx=\"470\" cy=\"120\" r=\"54\" fill=\"#bfffe9\" opacity=\".22\" filter=\"url(#mnb)\"/><circle cx=\"470\" cy=\"120\" r=\"38\" fill=\"url(#mnmoon)\"/><circle cx=\"459\" cy=\"112\" r=\"7\" fill=\"#a9d6c8\" opacity=\".5\"/><circle cx=\"482\" cy=\"133\" r=\"5\" fill=\"#a9d6c8\" opacity=\".45\"/><circle cx=\"360\" cy=\"390\" r=\"230\" fill=\"url(#mnglow)\"/><path d=\"M0 470L80 410 150 450 230 380 310 440 400 372 480 430 560 392 640 432 720 404V720H0Z\" fill=\"#0b1d2a\"/><path d=\"M0 530L100 480 180 512 280 470 370 516 470 474 560 506 650 482 720 500V720H0Z\" fill=\"#07131d\"/><rect y=\"420\" width=\"720\" height=\"150\" fill=\"url(#mnmist)\"/><path d=\"M276 476Q360 454 444 476L424 506Q396 534 360 542Q322 534 296 506Z\" fill=\"url(#mnrock)\"/><path d=\"M276 476Q360 454 444 476\" fill=\"none\" stroke=\"#3ff0b5\" stroke-opacity=\".7\" stroke-width=\"2\"/><ellipse cx=\"360\" cy=\"474\" rx=\"100\" ry=\"12\" fill=\"url(#mnpool)\"/></svg>";
  var MARK = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 48 48\" aria-hidden=\"true\"><defs><linearGradient id=\"lvexmoorg\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop offset=\"0\" stop-color=\"#8dffd9\"/><stop offset=\"1\" stop-color=\"#0f8f6a\"/></linearGradient></defs><path d=\"M6 14l10 6 8-14 8 14 10-6-5 26H11z\" fill=\"url(#lvexmoorg)\"/><path d=\"M24 6l-8 14 8 20 8-20z\" fill=\"#ffffff\" opacity=\".28\"/><rect x=\"11\" y=\"36\" width=\"26\" height=\"5\" rx=\"2\" fill=\"#9b7bff\"/></svg>";
  var K = 200 / 224, CROWN = { x: 60, y: 236 }, DRIFT = 0.5;

  function mx(pts) { return pts.map(function (p) { return [-p[0], p[1]]; }); }
  var S = [
    { o: [[-90, -55], [-67, -5], [-67, 30], [-90, 30]], dk: [[-90, -55], [-90, 30], [-78.5, 30]], l: [[-90, -55], [-78.5, 30], [-67, 30], [-67, -5]], hl: [[-90, -55], [-83.5, 14], [-75.5, 14]], star: [-90, -55, 7] },
    { o: [[-67, -5], [-45, -72], [-22, -5], [-22, 30], [-67, 30]], dk: [[-45, -72], [-67, -5], [-67, 30], [-45, 30]], l: [[-45, -72], [-45, 30], [-22, 30], [-22, -5]], hl: [[-45, -72], [-50, 14], [-42, 14]], star: [-45, -72, 9] },
    { o: [[-22, -5], [0, -94], [22, -5], [22, 30], [-22, 30]], dk: [[0, -94], [-22, -5], [-22, 30], [0, 30]], l: [[0, -94], [0, 30], [22, 30], [22, -5]], hl: [[0, -94], [-5, 14], [3, 14]], star: [0, -94, 15] }
  ];
  S.push({ o: mx(S[1].o), dk: mx(S[1].l), l: mx(S[1].dk), hl: mx(S[1].hl), star: [45, -72, 9] });
  S.push({ o: mx(S[0].o), dk: mx(S[0].l), l: mx(S[0].dk), hl: mx(S[0].hl), star: [90, -55, 7] });
  S.forEach(function (s) {
    var xs = s.o.map(function (p) { return p[0]; }), ys = s.o.map(function (p) { return p[1]; });
    s.bx = Math.min.apply(0, xs); s.by = Math.min.apply(0, ys); s.bw = Math.max.apply(0, xs) - s.bx; s.bh = Math.max.apply(0, ys) - s.by;
  });

  function pts(a) { return a.map(function (p) { return p[0] + ',' + p[1]; }).join(' '); }
  function grads(p) {
    return '<linearGradient id="' + p + 'd" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#29c793"/><stop offset=".55" stop-color="#0b7258"/><stop offset="1" stop-color="#05382c"/></linearGradient>' +
      '<linearGradient id="' + p + 'l" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#e6fff6"/><stop offset=".35" stop-color="#7cf5cf"/><stop offset="1" stop-color="#1fae80"/></linearGradient>';
  }
  function spike(s, p, withStar) {
    var g = '<polygon points="' + pts(s.dk) + '" fill="url(#' + p + 'd)" opacity=".95"/><polygon points="' + pts(s.l) + '" fill="url(#' + p + 'l)" opacity=".93"/>' +
      '<polygon points="' + pts(s.hl) + '" fill="#fff" opacity=".32"/><polygon points="' + pts(s.o) + '" fill="none" stroke="#c9fff0" stroke-width="1.6" stroke-linejoin="round" opacity=".9"/>';
    if (withStar) {
      var x = s.star[0], y = s.star[1], r = s.star[2], q = r * 0.16;
      g += '<path d="M' + x + ' ' + (y - r) + 'C' + (x + q) + ' ' + (y - q) + ' ' + (x + q) + ' ' + (y - q) + ' ' + (x + r) + ' ' + y + 'C' + (x + q) + ' ' + (y + q) + ' ' + (x + q) + ' ' + (y + q) + ' ' + x + ' ' + (y + r) +
        'C' + (x - q) + ' ' + (y + q) + ' ' + (x - q) + ' ' + (y + q) + ' ' + (x - r) + ' ' + y + 'C' + (x - q) + ' ' + (y - q) + ' ' + (x - q) + ' ' + (y - q) + ' ' + x + ' ' + (y - r) + 'Z" fill="#fff"/>';
    }
    return g;
  }

  function crownSvg() {
    var s = '<svg viewBox="-112 -112 224 196"><defs>' + grads('x54c') +
      '<linearGradient id="x54b" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fbe6bb"/><stop offset=".45" stop-color="#c0914c"/><stop offset=".7" stop-color="#8a6230"/><stop offset="1" stop-color="#e9c98f"/></linearGradient>' +
      '<radialGradient id="x54g" cx=".35" cy=".3" r=".75"><stop offset="0" stop-color="#e2d8ff"/><stop offset=".45" stop-color="#7b5bff"/><stop offset="1" stop-color="#2a1a7a"/></radialGradient>' +
      '<radialGradient id="x54h" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#3ff0b5" stop-opacity=".55"/><stop offset=".55" stop-color="#3ff0b5" stop-opacity=".12"/><stop offset="1" stop-color="#3ff0b5" stop-opacity="0"/></radialGradient></defs>';
    s += '<ellipse class="halo" cx="0" cy="-10" rx="118" ry="92" fill="url(#x54h)"/>';
    s += '<ellipse cx="0" cy="76" rx="92" ry="8" fill="#3ff0b5" opacity=".18"/>';
    S.forEach(function (sp, i) {
      s += '<polygon class="gh" data-i="' + i + '" points="' + pts(sp.o) + '" fill="#3ff0b5" fill-opacity=".07" stroke="#c9fff0" stroke-opacity=".55" stroke-width="1.3" stroke-dasharray="4 3" stroke-linejoin="round"/>';
    });
    S.forEach(function (sp, i) { s += '<g class="sp" data-i="' + i + '">' + spike(sp, 'x54c', true) + '</g>'; });
    s += '<rect x="-96" y="28" width="192" height="36" rx="8" fill="url(#x54b)"/><rect x="-96" y="28" width="192" height="36" rx="8" fill="none" stroke="#fff3d6" stroke-width="1" opacity=".8"/><rect x="-90" y="31" width="180" height="4" rx="2" fill="#fff" opacity=".35"/>';
    [-64, -32, 0, 32, 64].forEach(function (x, i) {
      var r = x === 0 ? 9 : 6.5;
      s += '<circle cx="' + x + '" cy="47" r="' + r + '" fill="#2a1d14" opacity=".55"/>' +
        '<g class="gem" data-i="' + i + '" opacity="0"><circle cx="' + x + '" cy="47" r="' + r + '" fill="url(#x54g)"/><circle cx="' + (x - 2) + '" cy="44" r="2" fill="#fff" opacity=".8"/></g>';
    });
    return s + '</svg>';
  }

  function shardSvg(sp, i) {
    var pad = 6, vb = [sp.bx - pad, sp.by - pad, sp.bw + pad * 2, sp.bh + pad * 2];
    return '<svg viewBox="' + vb.join(' ') + '" width="' + (vb[2] * K * DRIFT).toFixed(1) + '" height="' + (vb[3] * K * DRIFT).toFixed(1) + '" aria-hidden="true"><defs>' + grads('x54s' + i) + '</defs>' + spike(sp, 'x54s' + i, false) + '</svg>';
  }

  var ad = document.getElementById('ad'), crownBox = document.getElementById('crown'), box = document.getElementById('shards');
  var live = document.getElementById('live'), end = document.getElementById('end'), cta2 = document.getElementById('cta2');
  var scene = JXH.svg(SCENE);
  // move the scene's moon (and its craters / halo) to the top-end corner, clear of the headline
  [].forEach.call(scene.querySelectorAll('circle'), function (c) {
    var cx = +c.getAttribute('cx'), cy = +c.getAttribute('cy');
    if (cx >= 455 && cx <= 485 && cy >= 110 && cy <= 135) c.setAttribute('transform', 'translate(76 -60)');
  });
  document.getElementById('scene').appendChild(scene);
  document.getElementById('mark').appendChild(JXH.svg(MARK));
  crownBox.appendChild(JXH.svg(crownSvg()));
  JXH.wireCta(document.getElementById('cta1'));
  JXH.wireCta(cta2);

  // drift paths (centres in CSS px; the art is symmetric, so RTL keeps them)
  var BASE = [[58, 196], [126, 158], [200, 178], [264, 204], [152, 226]];
  var shards = [], placed = 0, over = false, lastTap = 0, t0 = performance.now();
  function posOf(s, t) {
    var b = BASE[s.i], x = b[0], y = b[1];
    if (!JXH.reduce) { x += 14 * Math.sin(t * 0.00055 + s.i * 1.7); y += 9 * Math.sin(t * 0.0008 + s.i * 2.3); }
    return [x, y];
  }
  function put(s, x, y, sc) { s.el.style.transform = 'translate(' + (x - 28).toFixed(1) + 'px,' + (y - 28).toFixed(1) + 'px)' + (sc ? ' scale(' + sc + ')' : ''); }

  S.forEach(function (sp, i) {
    var b = document.createElement('button');
    b.type = 'button'; b.className = 'shard';
    b.setAttribute('aria-label', 'Glowing shard ' + (i + 1) + ': place it in the crown');
    b.appendChild(JXH.svg(shardSvg(sp, i)));
    var s = { i: i, el: b, done: false };
    b.addEventListener('click', function () { take(s); });
    shards.push(s); box.appendChild(b);
    var p = posOf(s, 0); put(s, p[0], p[1]);
  });

  function light(i) {
    crownBox.querySelector('.sp[data-i="' + i + '"]').classList.add('on');
    crownBox.querySelector('.gh[data-i="' + i + '"]').style.opacity = '0';
    crownBox.querySelector('.gem[data-i="' + i + '"]').setAttribute('opacity', '1');
  }
  function nextFocus() {
    var rest = shards.filter(function (s) { return !s.done; });
    return rest[0] ? rest[0].el : null;
  }
  function take(s) {
    if (s.done || over) return;
    s.done = true; lastTap = Date.now();
    var hadFocus = document.activeElement === s.el;
    var sp = S[s.i], tx = CROWN.x + (sp.bx + sp.bw / 2 + 112) * K, ty = CROWN.y + (sp.by + sp.bh / 2 + 112) * K;
    function land() {
      if (s.el.parentNode) s.el.parentNode.removeChild(s.el);
      light(s.i); placed++;
      live.textContent = placed < 5 ? 'Shard placed.' : 'The crown is complete.';
      if (placed === 5) { ad.classList.add('whole'); setTimeout(finish, JXH.reduce ? 300 : 900); }
    }
    if (hadFocus) { var n = nextFocus(); if (n) n.focus(); }
    if (JXH.reduce) { land(); return; }
    s.el.classList.add('fly');
    put(s, tx, ty, 1 / DRIFT);
    setTimeout(land, 520);
  }
  function finish() {
    if (over) return;
    over = true;
    var a = document.activeElement, focusInside = document.hasFocus() && (!a || a === document.body || (a.classList && a.classList.contains('shard')));
    S.forEach(function (sp, i) { light(i); });
    shards.forEach(function (s) { s.done = true; });
    ad.classList.add('whole', 'over');
    end.setAttribute('aria-hidden', 'false');
    cta2.removeAttribute('tabindex');
    live.textContent = 'Vexmoor: Crown of Glass. Build. Defend. Rule the moor.';
    if (focusInside) { try { cta2.focus({ preventScroll: true }); } catch (e) { } }
  }
  (function check() {
    if (over) return;
    var t = performance.now() - t0;
    if (t >= 10000 && (Date.now() - lastTap > 1500 || t > 13000)) { finish(); return; }
    setTimeout(check, 250);
  })();
  if (!JXH.reduce) {
    (function frame(t) {
      if (over) return;
      shards.forEach(function (s) { if (!s.done) { var p = posOf(s, t - t0); put(s, p[0], p[1]); } });
      requestAnimationFrame(frame);
    })(t0);
  }
})();
