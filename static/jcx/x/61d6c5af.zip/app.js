/* Shared part of the JavCMS example HTML5 creatives (X53-X55).
 * The host passes a fragment: #w=300&h=250&dir=ltr|rtl[&rm=1][&u=<https click URL>] (IAB "clickTag" also accepted).
 * rm=1 (or prefers-reduced-motion) = no motion. No storage, no network, no same-origin access:
 * the host serves the files with "CSP: sandbox allow-scripts allow-popups allow-popups-to-escape-sandbox". */
var JXH = (function () {
  'use strict';
  var q = {};
  (location.hash.slice(1) + '&' + location.search.slice(1)).split('&').forEach(function (p) {
    var i = p.indexOf('=');
    if (i > 0) { try { q[decodeURIComponent(p.slice(0, i))] = decodeURIComponent(p.slice(i + 1)); } catch (e) { } }
  });
  var root = document.documentElement;
  var dir = q.dir === 'rtl' ? 'rtl' : 'ltr';
  root.setAttribute('dir', dir);
  var url = q.u || q.clickTag || q.clicktag || '';
  if (!/^https?:\/\/[^\s]+$/i.test(url) || /[\u0000-\u001f]/.test(url)) url = '';
  var w = Math.max(50, Math.min(1000, parseInt(q.w, 10) || 0)), h = Math.max(50, Math.min(1050, parseInt(q.h, 10) || 0));
  var mq = window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)') : null;
  var reduce = q.rm === '1' || !!(mq && mq.matches);
  if (reduce) root.classList.add('rm');
  // Better Ads / ADS-BRIEF 11.4: looping animation stops after 15 s (class "still" turns CSS animations off)
  setTimeout(function () { root.classList.add('still'); }, 15000);
  function open() { if (url) { try { window.open(url, '_blank', 'noopener'); } catch (e) { } } }
  function wireCta(btn) {
    if (!btn) return;
    if (!url) { btn.hidden = true; return; }
    btn.addEventListener('click', open);
  }
  function svg(markup) {
    var t = document.createElement('template');
    t.innerHTML = markup.trim();
    return t.content.firstElementChild;
  }
  return { q: q, dir: dir, rtl: dir === 'rtl', url: url, w: w, h: h, reduce: reduce, open: open, wireCta: wireCta, svg: svg };
})();

/* Ostrelle (fictional advertiser) tap-to-reveal, 300 x 250. Three stays flip to show the price; after three flips
 * or 8 s the "See stays" button appears and opens the click URL the host passes (#u=...). Art: inline SVG only. */
/* Ostrelle (fictional advertiser) stay pictures: scene(0|1|2) -> SVG markup of Cove Cabin, Cliff House, Beach Hut (88 x 120).
 * Shared by the X53 HTML5 ad and the X33 landing page. idp = id prefix (unique per document). */
var OSTRELLE_ART = (function () {
  'use strict';
  function sea(id, y, top, bottom) {
    return '<linearGradient id="' + id + '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + top + '"/><stop offset="1" stop-color="' + bottom + '"/></linearGradient>';
  }
  function glints(cx, y0, n) {
    var s = '', i, w, y;
    for (i = 0; i < n; i++) {
      y = y0 + 2 + i * 3.2; w = 6 + i * 3.4 - (i % 2) * 2;
      s += '<rect x="' + (cx - w / 2 + ((i * 7) % 5) - 2).toFixed(1) + '" y="' + y.toFixed(1) + '" width="' + w.toFixed(1) + '" height="1.2" rx=".6" fill="#ffe6b0" opacity="' + (0.85 - i * 0.07).toFixed(2) + '"/>';
    }
    return s;
  }
  function scene(i, idp) {
    var p = (idp || 't') + i, s = '<svg viewBox="0 0 88 120" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><defs>';
    var skies = [
      ['#40398a', '#a3518a', '#ef7d78', '#ffc684'],
      ['#2f2c74', '#7b4b93', '#d9677f', '#ffa978'],
      ['#4b3b86', '#c45f86', '#ff9a6e', '#ffd893']
    ][i];
    s += '<linearGradient id="' + p + 's" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + skies[0] + '"/><stop offset=".45" stop-color="' + skies[1] + '"/><stop offset=".78" stop-color="' + skies[2] + '"/><stop offset="1" stop-color="' + skies[3] + '"/></linearGradient>';
    s += '<radialGradient id="' + p + 'u" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#fffbe6"/><stop offset=".65" stop-color="#ffe29a"/><stop offset="1" stop-color="#ffc56e"/></radialGradient>';
    s += '<radialGradient id="' + p + 'g" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#ffd59a" stop-opacity=".85"/><stop offset="1" stop-color="#ffb36b" stop-opacity="0"/></radialGradient>';
    s += sea(p + 'w', 0, '#e88a7c', '#3a2a5e');
    s += '<linearGradient id="' + p + 'f" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#1c0f24" stop-opacity=".78"/></linearGradient>';
    s += '<clipPath id="' + p + 'c"><rect width="88" height="78"/></clipPath></defs>';
    s += '<rect width="88" height="78" fill="url(#' + p + 's)"/>';
    // stars on the high sky
    s += '<circle cx="12" cy="10" r=".7" fill="#fff" opacity=".7"/><circle cx="70" cy="18" r=".6" fill="#fff" opacity=".6"/><circle cx="40" cy="6" r=".5" fill="#fff" opacity=".5"/>';
    if (i === 0) {
      s += '<circle cx="60" cy="74" r="30" fill="url(#' + p + 'g)"/><g clip-path="url(#' + p + 'c)"><circle cx="60" cy="79" r="13" fill="url(#' + p + 'u)"/></g>';
      s += '<rect y="78" width="88" height="42" fill="url(#' + p + 'w)"/>' + glints(60, 78, 7);
      s += '<path d="M0 120V98q14-10 30-8t30 8 28 4v18z" fill="#4c2c5e"/><path d="M0 120v-14q18-8 40-4t48 6v12z" fill="#2c1a3a"/>';
      // cabin on the dune
      s += '<path d="M16 96h26v-12H16z" fill="#2c1a3a"/><path d="M13.5 85.5L29 73l15.5 12.5" fill="none" stroke="#2c1a3a" stroke-width="3.2" stroke-linejoin="round" stroke-linecap="round"/><path d="M16 85L29 74.5 42 85v2H16z" fill="#2c1a3a"/>';
      s += '<rect x="21" y="87" width="5" height="5" rx=".6" fill="#ffd59a"/><rect x="31" y="86" width="6" height="10" rx=".6" fill="#ffc06e" opacity=".9"/><circle cx="23.5" cy="89.5" r="5" fill="#ffd59a" opacity=".18"/>';
      s += '<path d="M48 94q1-6 2-8M52 95q0-5 2-7M6 100q1-5 3-6" stroke="#2c1a3a" stroke-width="1.2" fill="none" stroke-linecap="round"/>';
    } else if (i === 1) {
      s += '<circle cx="26" cy="74" r="30" fill="url(#' + p + 'g)"/><g clip-path="url(#' + p + 'c)"><circle cx="26" cy="80" r="12" fill="url(#' + p + 'u)"/></g>';
      s += '<rect y="78" width="88" height="42" fill="url(#' + p + 'w)"/>' + glints(26, 78, 7);
      s += '<path d="M46 120L50 98 47 84 52 70 64 66H88v54z" fill="#2c1a3a"/><path d="M47 84l5-14 12-4" fill="none" stroke="#7a4a7c" stroke-width="1" opacity=".8"/>';
      // cliff house: one long glass box under a thin roof slab, lit from inside
      s += '<rect x="55" y="55" width="33" height="11" fill="#3b2140"/><rect x="53" y="53" width="37" height="2.2" rx=".6" fill="#6b3f73"/>';
      s += '<rect x="58" y="57.6" width="27" height="6" fill="#ffd59a"/><path d="M64.5 57.6v6M71 57.6v6M77.5 57.6v6" stroke="#3b2140" stroke-width="1"/><rect x="58" y="57.6" width="27" height="1.4" fill="#fff1d6" opacity=".7"/>';
      s += '<path d="M56 66h-6" stroke="#3b2140" stroke-width="1.4"/><ellipse cx="72" cy="62" rx="22" ry="7" fill="#ffd59a" opacity=".13"/>';
    } else {
      s += '<circle cx="40" cy="72" r="34" fill="url(#' + p + 'g)"/><g clip-path="url(#' + p + 'c)"><circle cx="40" cy="78" r="15" fill="url(#' + p + 'u)"/></g>';
      s += '<rect y="78" width="88" height="42" fill="url(#' + p + 'w)"/>' + glints(40, 78, 5);
      s += '<path d="M0 120v-18q22-6 44-3t44 5v16z" fill="#7a4258"/><path d="M0 120v-10q30-6 88 0v10z" fill="#4c2c5e"/>';
      // hut on stilts
      s += '<path d="M54 102V90M60 103V90M70 103V90M76 102V90" stroke="#2c1a3a" stroke-width="1.6"/><rect x="50" y="88" width="30" height="2.4" fill="#2c1a3a"/>';
      s += '<rect x="54" y="77" width="22" height="11" fill="#2c1a3a"/><path d="M49 78.5L65 66l16 12.5z" fill="#3b2140"/><path d="M49 78.5L65 66l16 12.5" fill="none" stroke="#2c1a3a" stroke-width="1.6" stroke-linejoin="round"/>';
      s += '<rect x="62" y="80" width="6" height="8" rx=".6" fill="#ffc06e"/><path d="M80 90l5 12" stroke="#2c1a3a" stroke-width="1.4"/>';
      // palm
      s += '<path d="M16 104q2-16 9-28" fill="none" stroke="#2c1a3a" stroke-width="2.2" stroke-linecap="round"/>';
      s += '<path d="M25 76q-9-4-16 2q8-1 16-2zM25 76q-3-9-11-10q6 4 11 10zM25 76q6-8 15-6q-8 1-15 6zM25 76q9-1 13 6q-6-5-13-6zM25 76q2-9 9-12q-6 5-9 12z" fill="#2c1a3a"/>';
    }
    s += '<rect y="70" width="88" height="50" fill="url(#' + p + 'f)"/></svg>';
    return s;
  }

  return { scene: scene };
})();

(function () {
  'use strict';
  var MARK = '<svg viewBox="0 0 48 48" aria-hidden="true"><circle cx="24" cy="24" r="22" fill="#0f6b73"/><path d="M10 26a14 14 0 0 1 28 0z" fill="#ffb36b"/><path d="M8 31h32M12 36h24" stroke="#fff1de" stroke-width="3" stroke-linecap="round"/></svg>';
  var FLIP = '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M13 6.5A5.2 5.2 0 0 0 3.6 5M3 9.5A5.2 5.2 0 0 0 12.4 11" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><path d="M3 2.4V5.4h3M13 13.6v-3h-3" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  var ICONS = {
    bed: '<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M1 9.5V3M1 7h10v2.5M11 7V5.6c0-.9-.7-1.6-1.6-1.6H5.5V7" fill="none" stroke="#0f6b73" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/><circle cx="3.2" cy="5.3" r="1.1" fill="#0f6b73"/></svg>',
    view: '<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M1 8.5h10M2.5 8.5a3.5 3.5 0 0 1 7 0" fill="none" stroke="#0f6b73" stroke-width="1.2" stroke-linecap="round"/><path d="M6 1.6v1.4M2.2 3.2l1 1M9.8 3.2l-1 1" stroke="#0f6b73" stroke-width="1.2" stroke-linecap="round"/></svg>',
    wave: '<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M1 5.2c1.2-1 2.3-1 3.4 0s2.3 1 3.4 0 2.3-1 3.2 0M1 8.4c1.2-1 2.3-1 3.4 0s2.3 1 3.4 0 2.3-1 3.2 0" fill="none" stroke="#0f6b73" stroke-width="1.2" stroke-linecap="round"/></svg>'
  };

  var STAYS = [
    { name: 'Cove Cabin', price: '$289', detail: 'Sleeps 2', icon: 'bed' },
    { name: 'Cliff House', price: '$349', detail: 'Sea view', icon: 'view' },
    { name: 'Beach Hut', price: '$219', detail: 'Beachfront', icon: 'wave' }
  ];

  var ad = document.getElementById('ad'), tiles = document.getElementById('tiles');
  var hint = document.getElementById('hint'), cta = document.getElementById('cta');
  document.getElementById('mark').appendChild(JXH.svg(MARK));
  var seen = 0, done = false;

  function finish(all) {
    if (done) return;
    done = true;
    ad.classList.add('done');
    if (all) hint.textContent = 'Prices for two guests.';
  }

  STAYS.forEach(function (st, i) {
    var b = document.createElement('button');
    b.type = 'button'; b.className = 'tile';
    b.setAttribute('aria-pressed', 'false');
    b.setAttribute('aria-label', st.name + '. Show the price');
    var front = document.createElement('span'); front.className = 'face front';
    front.appendChild(JXH.svg(OSTRELLE_ART.scene(i)));
    var nm = document.createElement('span'); nm.className = 'name'; nm.textContent = st.name; front.appendChild(nm);
    var fl = document.createElement('span'); fl.className = 'flip'; fl.appendChild(JXH.svg(FLIP)); front.appendChild(fl);
    var back = document.createElement('span'); back.className = 'face back'; back.setAttribute('aria-hidden', 'true');
    [['bn', st.name], ['bl', '3 nights'], ['bp', st.price]].forEach(function (r) {
      var e = document.createElement('span'); e.className = r[0]; e.textContent = r[1]; back.appendChild(e);
    });
    var d = document.createElement('span'); d.className = 'bd'; d.appendChild(JXH.svg(ICONS[st.icon]));
    d.appendChild(document.createTextNode(st.detail)); back.appendChild(d);
    b.appendChild(front); b.appendChild(back);
    b.addEventListener('click', function () {
      var open = !b.classList.contains('open');
      b.classList.toggle('open', open);
      b.setAttribute('aria-pressed', open ? 'true' : 'false');
      b.setAttribute('aria-label', open ? st.name + ', 3 nights ' + st.price + ', ' + st.detail.toLowerCase() : st.name + '. Show the price');
      if (open && !b.classList.contains('seen')) {
        b.classList.add('seen'); seen++;
        if (seen === STAYS.length) finish(true);
      }
    });
    tiles.appendChild(b);
  });

  JXH.wireCta(cta);
  setTimeout(function () { finish(false); }, 8000);
})();
