/* Shared part of the JavCMS example HTML5 creatives (X53-X55).
 * The host passes a fragment: #w=300&h=250&dir=ltr|rtl[&rm=1][&u=<https click URL>] (IAB "clickTag" also accepted).
 * rm=1 (or prefers-reduced-motion) = no motion. No storage, no network, no same-origin access:
 * the host serves the files with "CSP: sandbox allow-scripts allow-popups allow-popups-to-escape-sandbox". */
var JXH = (function () {
  'use strict';
  var q = {};
  (location.hash.slice(1) + '&' + location.search.slice(1)).split('&').forEach(function (p) {
    var i = p.indexOf('=');
    if (i > 0) { try { q[decodeURIComponent(p.slice(0, i))] = decodeURIComponent(p.slice(i + 1)); } catch (e) { } }
  });
  var root = document.documentElement;
  var dir = q.dir === 'rtl' ? 'rtl' : 'ltr';
  root.setAttribute('dir', dir);
  var url = q.u || q.clickTag || q.clicktag || '';
  if (!/^https?:\/\/[^\s]+$/i.test(url) || /[\u0000-\u001f]/.test(url)) url = '';
  var w = Math.max(50, Math.min(1000, parseInt(q.w, 10) || 0)), h = Math.max(50, Math.min(1050, parseInt(q.h, 10) || 0));
  var mq = window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)') : null;
  var reduce = q.rm === '1' || !!(mq && mq.matches);
  if (reduce) root.classList.add('rm');
  // Better Ads / ADS-BRIEF 11.4: looping animation stops after 15 s (class "still" turns CSS animations off)
  setTimeout(function () { root.classList.add('still'); }, 15000);
  function open() { if (url) { try { window.open(url, '_blank', 'noopener'); } catch (e) { } } }
  function wireCta(btn) {
    if (!btn) return;
    if (!url) { btn.hidden = true; return; }
    btn.addEventListener('click', open);
  }
  function svg(markup) {
    var t = document.createElement('template');
    t.innerHTML = markup.trim();
    return t.content.firstElementChild;
  }
  return { q: q, dir: dir, rtl: dir === 'rtl', url: url, w: w, h: h, reduce: reduce, open: open, wireCta: wireCta, svg: svg };
})();

/* Corvella (fictional dating service) 360 panorama, 300 x 250: a lantern-lit rooftop terrace set for two, objects only.
 * One 1200 x 250 inline SVG strip (drawn twice for the wrap) panned by drag, touch or the arrow keys. */
(function () {
  'use strict';
  var MARK = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 48 48\" aria-hidden=\"true\"><circle cx=\"18\" cy=\"26\" r=\"11\" fill=\"none\" stroke=\"#e8b49a\" stroke-width=\"3.5\"/><circle cx=\"30\" cy=\"22\" r=\"11\" fill=\"none\" stroke=\"#ff8fa3\" stroke-width=\"3.5\"/></svg>";
  var W = 1200, H = 250, VIEW = 300;
  var seed = 7;
  function rnd() { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; }
  function f(n) { return Math.round(n * 10) / 10; }

  function skyline(y0, hMin, hMax, wMin, wMax, fill, win, winOp, gap) {
    var s = '', x = 0, w, h, top, wx, wy;
    while (x < W) {
      w = Math.round(wMin + rnd() * (wMax - wMin));
      if (W - x - w < wMin) w = W - x;
      h = Math.round(hMin + rnd() * (hMax - hMin)); top = y0 - h;
      s += '<rect x="' + x + '" y="' + top + '" width="' + (w - gap) + '" height="' + (h + 20) + '" fill="' + fill + '"/>';
      if (rnd() < 0.35) s += '<rect x="' + (x + Math.round(w * 0.3)) + '" y="' + (top - 6) + '" width="' + Math.max(4, Math.round(w * 0.25)) + '" height="6" fill="' + fill + '"/>';
      for (wy = top + 6; wy < y0 - 4; wy += 7) {
        for (wx = x + 4; wx < x + w - gap - 5; wx += 6) {
          if (rnd() < 0.22) s += '<rect x="' + wx + '" y="' + wy + '" width="2.4" height="3" fill="' + win + '" opacity="' + f(winOp * (0.5 + rnd() * 0.5)) + '"/>';
        }
      }
      x += w;
    }
    return s;
  }

  function chair(x, flip) {
    // bistro chair in profile, back on the outside, facing the table
    var g = '<g transform="translate(' + x + ' 0)' + (flip ? ' scale(-1 1)' : '') + '">';
    g += '<path d="M2 238L4 214M26 214L30 238M4 214H28" fill="none" stroke="#e8b49a" stroke-width="2.4" stroke-linecap="round"/>';
    g += '<path d="M4 214Q1 196 0 178Q0 172 6 172Q10 172 10 178L8 212" fill="none" stroke="#e8b49a" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>';
    g += '<path d="M3 186h6M2.5 196h6" stroke="#e8b49a" stroke-width="1.6" stroke-linecap="round"/>';
    g += '<rect x="4" y="209" width="25" height="5" rx="2.5" fill="#ff8fa3"/><rect x="5" y="209" width="22" height="1.6" rx=".8" fill="#ffd0d9" opacity=".8"/>';
    return g + '</g>';
  }
  function cup(x, body, rim) {
    return '<ellipse cx="' + x + '" cy="200.5" rx="8" ry="1.8" fill="#f6d9cf"/>' +
      '<path d="M' + (x - 5) + ' 192h10l-1.3 7.2q-.3 1.3-1.6 1.3h-4.2q-1.3 0-1.6-1.3z" fill="' + body + '"/>' +
      '<path d="M' + (x + 4.6) + ' 194q3.2-.3 3.2 2.1t-3.8 2.2" fill="none" stroke="' + body + '" stroke-width="1.3"/>' +
      '<ellipse cx="' + x + '" cy="192" rx="5" ry="1.1" fill="' + rim + '"/>';
  }
  function steam(x, d) {
    return '<path class="steam' + (d ? ' d1' : '') + '" d="M' + x + ' 189q-2-3 0-6t0-6" fill="none" stroke="#fff2f4" stroke-width="1.1" stroke-linecap="round" opacity=".6"/>';
  }
  function lantern(x) {
    return '<ellipse cx="' + x + '" cy="232" rx="34" ry="7" fill="url(#cvp)"/><circle cx="' + x + '" cy="212" r="22" fill="url(#cvl)"/>' +
      '<path d="M' + (x - 4) + ' 193q4-6 8 0" fill="none" stroke="#e8b49a" stroke-width="1.6"/>' +
      '<rect x="' + (x - 9) + '" y="196" width="18" height="3" rx="1" fill="#e8b49a"/><rect x="' + (x - 8) + '" y="199" width="16" height="25" rx="2" fill="#ffd59a" opacity=".9"/>' +
      '<path d="M' + (x - 8) + ' 199v25M' + (x + 8) + ' 199v25M' + x + ' 199v25" stroke="#7a3a2a" stroke-width="1.2"/><rect x="' + (x - 10) + '" y="224" width="20" height="3" rx="1" fill="#e8b49a"/>' +
      '<ellipse cx="' + x + '" cy="214" rx="3" ry="5" fill="#fffbe6"/>';
  }
  function olive(x) {
    var s = '<path d="M' + (x - 11) + ' 216h22l-3 22h-16z" fill="#6a2a3e"/><rect x="' + (x - 12) + '" y="214" width="24" height="3" rx="1" fill="#8a3a52"/>';
    s += '<path d="M' + x + ' 214q-1-18 2-34M' + x + ' 200q6-6 10-14M' + x + ' 196q-6-5-9-13" fill="none" stroke="#3a1a22" stroke-width="2" stroke-linecap="round"/>';
    [[-14, 172, 13, 9], [2, 164, 15, 10], [14, 180, 12, 8], [-4, 182, 12, 8], [-16, 186, 9, 6], [12, 168, 9, 7]].forEach(function (b, i) {
      s += '<ellipse cx="' + (x + b[0]) + '" cy="' + b[1] + '" rx="' + b[2] + '" ry="' + b[3] + '" fill="' + (i % 2 ? '#2f4a3a' : '#3d5e46') + '"/>';
    });
    return s + '<ellipse cx="' + (x - 2) + '" cy="168" rx="8" ry="3" fill="#ffcf9a" opacity=".12"/>';
  }
  function bulbs(x0, x1) {
    // one sagging wire between two posts (tops at y 34), with eight warm bulbs
    var mx = (x0 + x1) / 2, cy = 88, s = '<path d="M' + x0 + ' 34Q' + mx + ' ' + cy + ' ' + x1 + ' 34" fill="none" stroke="#14060c" stroke-width="1.2"/>';
    for (var i = 1; i <= 8; i++) {
      var t = i / 9, x = (1 - t) * (1 - t) * x0 + 2 * (1 - t) * t * mx + t * t * x1, y = (1 - t) * (1 - t) * 34 + 2 * (1 - t) * t * cy + t * t * 34;
      var cls = i % 3 === 0 ? ' class="tw"' : i % 3 === 1 ? ' class="tw d1"' : ' class="tw d2"';
      s += '<g' + cls + '><circle cx="' + f(x) + '" cy="' + f(y + 4) + '" r="8" fill="url(#cvb)"/><circle cx="' + f(x) + '" cy="' + f(y + 4) + '" r="2.6" fill="#ffe7bd"/></g>' +
        '<path d="M' + f(x) + ' ' + f(y) + 'v1.6" stroke="#14060c" stroke-width="1.4"/>';
    }
    return s;
  }
  function post(x) { return '<rect x="' + (x - 1.5) + '" y="30" width="3" height="150" fill="#14060c"/><circle cx="' + x + '" cy="31" r="2.4" fill="#e8b49a"/>'; }
  function fg(cx, inner) { return '<g transform="translate(' + cx + ' 242) scale(1.55) translate(' + (-cx) + ' -238)">' + inner + '</g>'; }

  function sceneSvg() {
    seed = 7;
    var s = '<svg viewBox="0 0 ' + W + ' ' + H + '" preserveAspectRatio="none" aria-hidden="true"><defs>' +
      '<linearGradient id="cvs" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1c0912"/><stop offset=".3" stop-color="#3d1228"/><stop offset=".5" stop-color="#7a2a48"/><stop offset=".75" stop-color="#c25a6e"/><stop offset=".92" stop-color="#eb9583"/></linearGradient>' +
      '<linearGradient id="cvd" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3a1424"/><stop offset="1" stop-color="#170710"/></linearGradient>' +
      '<radialGradient id="cvb" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#ffcf8a" stop-opacity=".75"/><stop offset="1" stop-color="#ff9a6a" stop-opacity="0"/></radialGradient>' +
      '<radialGradient id="cvl" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#ffcf8a" stop-opacity=".55"/><stop offset="1" stop-color="#ff9a6a" stop-opacity="0"/></radialGradient>' +
      '<radialGradient id="cvp" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#ffb36b" stop-opacity=".38"/><stop offset="1" stop-color="#ffb36b" stop-opacity="0"/></radialGradient>' +
      '<linearGradient id="cvt" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f6d896"/><stop offset=".45" stop-color="#d9a55a"/><stop offset="1" stop-color="#9a6a32"/></linearGradient>' +
      '<mask id="cvm"><rect width="' + W + '" height="' + H + '" fill="#fff"/><circle cx="937" cy="44" r="13" fill="#000"/></mask></defs>';
    s += '<rect width="' + W + '" height="160" fill="url(#cvs)"/>';
    for (var i = 0; i < 46; i++) s += '<circle cx="' + f(rnd() * W) + '" cy="' + f(6 + rnd() * 84) + '" r="' + f(0.4 + rnd() * 0.7) + '" fill="#fff" opacity="' + f(0.3 + rnd() * 0.5) + '"/>';
    s += '<circle cx="930" cy="48" r="26" fill="#ffe9e0" opacity=".08"/><circle cx="930" cy="48" r="13" fill="#fff2e6" mask="url(#cvm)"/>';
    s += skyline(156, 18, 52, 26, 64, '#5a1f3b', '#ffcf9a', 0.45, 3);
    s += skyline(156, 10, 36, 30, 80, '#2c0d1e', '#ffd59a', 0.85, 2);
    // parapet, deck and plank lines
    s += '<rect y="154" width="' + W + '" height="14" fill="#2a0e1c"/><rect y="154" width="' + W + '" height="1.4" fill="#e8b49a" opacity=".45"/>';
    s += '<rect y="168" width="' + W + '" height="82" fill="url(#cvd)"/>';
    [176, 190, 208, 232].forEach(function (y) { s += '<rect y="' + y + '" width="' + W + '" height="1" fill="#e8b49a" opacity=".07"/>'; });
    // string lights: posts every 300 px, the last wire wraps across the seam
    s += post(150) + post(450) + post(750) + post(1050);
    s += bulbs(150, 450) + bulbs(450, 750) + bulbs(750, 1050) + bulbs(1050, 1350) + bulbs(-150, 150);
    // foreground objects, drawn at ground y 238 and scaled 1.55 around their own base
    s += fg(100, '<ellipse cx="100" cy="240" rx="70" ry="5" fill="#000" opacity=".35"/><rect x="42" y="214" width="116" height="16" rx="4" fill="#4a1a30"/><rect x="42" y="208" width="116" height="9" rx="4" fill="#ecbdc9"/>' +
      '<path d="M46 230v8M154 230v8" stroke="#e8b49a" stroke-width="2.4" stroke-linecap="round"/>' +
      '<rect x="56" y="194" width="30" height="16" rx="6" fill="#ff8fa3" transform="rotate(-8 71 202)"/><rect x="92" y="194" width="30" height="16" rx="6" fill="#e8b49a" transform="rotate(6 107 202)"/>');
    s += fg(230, olive(230)) + fg(345, lantern(345)) + fg(1010, olive(1010)) + fg(880, lantern(880));
    var t = '<ellipse cx="600" cy="232" rx="90" ry="10" fill="url(#cvp)"/><ellipse cx="600" cy="194" rx="46" ry="30" fill="url(#cvl)"/>';
    t += chair(546, false) + chair(654, true);
    t += '<path d="M600 205v31" stroke="#e8b49a" stroke-width="2.6"/><ellipse cx="600" cy="237.5" rx="13" ry="2.6" fill="#e8b49a"/>';
    t += '<ellipse cx="600" cy="203" rx="31" ry="4.6" fill="#b9806a"/><ellipse cx="600" cy="202" rx="31" ry="4.2" fill="#e8b49a"/><ellipse cx="596" cy="201.2" rx="18" ry="1.6" fill="#fff2f4" opacity=".35"/>';
    t += cup(585, '#fff2f4', '#7a3a2a') + cup(615, '#ff8fa3', '#7a3a2a') + steam(584, 0) + steam(586.5, 1) + steam(614, 1) + steam(616.5, 0);
    t += '<rect x="596" y="190" width="8" height="11" rx="1.6" fill="#ffd59a" opacity=".85"/><rect x="595" y="188.6" width="10" height="2" rx="1" fill="#e8b49a"/><ellipse cx="600" cy="195.5" rx="1.6" ry="2.6" fill="#fffbe6"/>';
    s += fg(600, t);
    // brass refractor telescope on a tall, slim tripod, pointed up at the moon: a long, thin tapered tube with a dew
    // shield, a small finder scope on top and an eyepiece with a dark eye cup at the low end
    s += fg(796, '<ellipse cx="796" cy="239" rx="22" ry="2.6" fill="#000" opacity=".3"/>' +
      '<path d="M796 199L779 238M796 199L813 238M796 199v39" fill="none" stroke="#e8b49a" stroke-width="1.6" stroke-linecap="round"/>' +
      '<path d="M786.5 221h19" stroke="#e8b49a" stroke-width="1" stroke-linecap="round" opacity=".8"/>' +
      '<rect x="792.5" y="196" width="7" height="5" rx="1.2" fill="#b98a4e"/>' +
      '<g transform="rotate(-27 798 195)">' +
      '<path d="M768 193.2L834 191.6V198.4L768 196.8Z" fill="url(#cvt)"/>' +
      '<path d="M768 193.6L834 192.2" stroke="#fff3d6" stroke-width=".7" opacity=".7"/>' +
      '<rect x="831" y="190.4" width="11" height="9.2" rx="1.4" fill="url(#cvt)"/><rect x="831" y="190.4" width="1.6" height="9.2" fill="#8a5e2c"/>' +
      '<ellipse cx="842" cy="195" rx="1.1" ry="4.4" fill="#2a1630"/>' +
      '<rect x="784" y="192.4" width="2" height="5.6" rx=".5" fill="#8a5e2c"/><rect x="808" y="191.8" width="2" height="6.6" rx=".5" fill="#8a5e2c"/>' +
      '<path d="M790 192.6v-2.6M800 192.3v-2.6" stroke="#b98a4e" stroke-width="1"/><rect x="787" y="187.4" width="17" height="2.8" rx="1.2" fill="#e9c27e"/>' +
      '<rect x="761" y="193.6" width="7.4" height="2.8" rx=".6" fill="#c9954f"/><rect x="756.6" y="192.9" width="4.8" height="4.2" rx="1.2" fill="#2a1630"/>' +
      '<circle cx="796" cy="198.6" r="1.6" fill="#8a5e2c"/></g>');
    return s + '</svg>';
  }

  var PLACES = [[100, 'the daybed with two cushions'], [230, 'an olive tree'], [345, 'a lantern'], [600, 'the table for two, with two cups'],
    [800, 'a telescope pointed at the moon'], [880, 'a lantern'], [1010, 'an olive tree'], [1150, 'the city skyline']];

  var pano = document.getElementById('pano'), strip = document.getElementById('strip'), hint = document.getElementById('hint');
  document.getElementById('mark').appendChild(JXH.svg(MARK));
  var svgText = sceneSvg();
  strip.appendChild(JXH.svg(svgText)); strip.appendChild(JXH.svg(svgText));
  JXH.wireCta(document.getElementById('cta'));

  var x = 410, touched = false, dragging = false, lastX = 0, lastT = 0, vel = 0, raf = 0, lastText = '';
  function draw() {
    var off = ((x % W) + W) % W;
    strip.style.transform = 'translate3d(' + (-off).toFixed(1) + 'px,0,0)';
    var deg = Math.round(off / W * 360) % 360;
    pano.setAttribute('aria-valuenow', String(deg));
    var c = (off + VIEW / 2) % W, best = PLACES[0], d = 1e9;
    PLACES.forEach(function (p) { var dd = Math.min(Math.abs(p[0] - c), W - Math.abs(p[0] - c)); if (dd < d) { d = dd; best = p; } });
    var txt = deg + ' degrees, facing ' + best[1];
    if (txt !== lastText) { pano.setAttribute('aria-valuetext', txt); lastText = txt; }
  }
  function firstTouch() { if (!touched) { touched = true; hint.classList.add('gone'); } }
  function stopAnim() { if (raf) { cancelAnimationFrame(raf); raf = 0; } }

  pano.addEventListener('pointerdown', function (e) {
    if (e.button) return;
    firstTouch(); stopAnim(); dragging = true; lastX = e.clientX; lastT = performance.now(); vel = 0;
    pano.classList.add('drag');
    try { pano.setPointerCapture(e.pointerId); } catch (err) { }
  });
  pano.addEventListener('pointermove', function (e) {
    if (!dragging) return;
    var now = performance.now(), dx = e.clientX - lastX;
    x -= dx; vel = dx / Math.max(1, now - lastT); lastX = e.clientX; lastT = now; draw();
  });
  function up() {
    if (!dragging) return;
    dragging = false; pano.classList.remove('drag');
    if (JXH.reduce || Math.abs(vel) < 0.05) return;
    var v = vel * 16;
    (function glide() { v *= 0.92; x -= v; draw(); raf = Math.abs(v) > 0.3 ? requestAnimationFrame(glide) : 0; })();
  }
  pano.addEventListener('pointerup', up);
  pano.addEventListener('pointercancel', up);
  pano.addEventListener('lostpointercapture', up);
  pano.addEventListener('keydown', function (e) {
    var k = e.key, step = e.shiftKey ? 150 : 40;
    if (k === 'ArrowRight' || k === 'ArrowDown') x += step;
    else if (k === 'ArrowLeft' || k === 'ArrowUp') x -= step;
    else if (k === 'PageDown') x += 300;
    else if (k === 'PageUp') x -= 300;
    else if (k === 'Home') x = 410;
    else return;
    e.preventDefault(); firstTouch(); stopAnim(); draw();
  });

  draw();
  // gentle drift for 6 s until the first touch, never with reduced motion
  if (!JXH.reduce) {
    var t0 = performance.now(), prev = t0;
    (function spin(t) {
      if (touched || t - t0 > 6000) { raf = 0; return; }
      x += (t - prev) * 0.012; prev = t; draw();
      raf = requestAnimationFrame(spin);
    })(t0);
  }
})();
